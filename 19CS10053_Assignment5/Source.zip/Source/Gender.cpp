// Name : Satvik Bansal
// Roll No. : 19CS10053

#include <string>
using namespace std;
#include "Gender.h"
const string Male::sName = "Male";
const string Female::sName = "Female";

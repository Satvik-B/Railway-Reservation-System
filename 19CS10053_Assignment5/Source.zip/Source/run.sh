echo "Compiling"
g++ *.cpp -std=c++17 -O2
./a.out